<?php
// Heading
$_['heading_title']       = 'Layouts';

// Text
$_['text_success']        = 'Success: You have modified layouts!';
$_['text_list']           = 'Layout List';
$_['text_add']            = 'Add Layout';
$_['text_edit']           = 'Edit Layout';
$_['text_remove']         = 'Remove';
$_['text_route']          = 'Choose the store and routes to be used with this layout';
$_['text_module']         = 'Choose the position of the modules';
$_['text_default']        = 'Default';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';
$_['text_block1']   = 'Block 1';
$_['text_block2']   = 'Block 2';
$_['text_block3']   = 'Block 3';
$_['text_block4']   = 'Block 4';
$_['text_block5']   = 'Block 5';
$_['text_block6']   = 'Block 6';
$_['text_block7']   = 'Block 7';
$_['text_block8']   = 'Block 8';
$_['text_block9']   = 'Block 9';
$_['text_block10']   = 'Block 10';
$_['text_block11']   = 'Block 11';

// Column
$_['column_name']         = 'Layout Name';
$_['column_action']       = 'Action';

// Entry
$_['entry_name']          = 'Layout Name';
$_['entry_layout_name']          = 'Layout Name';
$_['entry_store']         = 'Store';
$_['entry_route']         = 'Route';
$_['entry_module']        = 'Module';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify layouts!';
$_['error_name']          = 'Layout Name must be between 3 and 64 characters!';
$_['error_default']       = 'Warning: This layout cannot be deleted as it is currently assigned as the default store layout!';
$_['error_store']         = 'Warning: This layout cannot be deleted as it is currently assigned to %s stores!';
$_['error_product']       = 'Warning: This layout cannot be deleted as it is currently assigned to %s products!';
$_['error_category']      = 'Warning: This layout cannot be deleted as it is currently assigned to %s categories!';
$_['error_information']   = 'Warning: This layout cannot be deleted as it is currently assigned to %s information pages!';