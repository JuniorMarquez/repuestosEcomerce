<?php
$_['text_theme_menu'] = "OC Theme Menu";

$_['text_theme_config'] = "Theme Configuration";

$_['text_category_thumbnail'] = "Featured Categories";

$_['text_advance_menu'] = 'Advanced Menu';

$_['text_blog'] = "Blog";
$_['text_article'] = "Articles";
$_['text_article_list'] = "Articles Lists";
$_['text_blog_config'] = "Configuration";

$_['text_cms_block'] = "CMS Blocks";

$_['text_testimonial'] = "Testimonials";

$_['text_slideshow'] = "Banner Sliders";