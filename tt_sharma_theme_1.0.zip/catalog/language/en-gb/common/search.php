<?php
// Text
$_['text_search'] = 'Search entire store here ...';
$_['button_search'] = 'Search';