<?php

// Heading
$_['heading_title']  = 'Login or create an account';