<?php
$_['heading_title']    = 'Products module';

// Text
$_['text_empty']    = 'There is no product';
$_['text_years']    = 'years';
$_['text_months']    = 'months';
$_['text_weeks']    = 'weeks';
$_['text_days']    = 'days';
$_['text_hrs']    = 'hours';
$_['text_mins']    = 'mins';
$_['text_secs']    = 'secs';

$_['text_year']    = 'years';
$_['text_month']    = 'months';
$_['text_week']    = 'weeks';
$_['text_day']    = 'days';
$_['text_hr']    = 'hours';
$_['text_min']    = 'mins';
$_['text_sec']    = 'secs';

$_['price_label']    = 'Price:';
$_['text_stock']    = 'Available:';
$_['text_instock']    = 'In Stock';
$_['text_availabe']    = 'Availabe:';
$_['text_sold']    = 'Sold:';

