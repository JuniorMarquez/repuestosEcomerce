<?php
$_['text_readmore'] = 'Shopping Now';