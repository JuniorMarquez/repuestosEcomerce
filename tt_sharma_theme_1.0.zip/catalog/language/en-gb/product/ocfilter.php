<?php
// Heading
$_['heading_title'] = 'Layered Navigation';
$_['text_filter_price'] = 'Fillter By Price';